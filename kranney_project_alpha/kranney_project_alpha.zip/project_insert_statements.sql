INSERT INTO students
VALUES ('Kyle', 'Jacob', 'Ranney', 'Insurance', NULL, 3.22, NULL, NULL, 2016, 'Breed, Carol')